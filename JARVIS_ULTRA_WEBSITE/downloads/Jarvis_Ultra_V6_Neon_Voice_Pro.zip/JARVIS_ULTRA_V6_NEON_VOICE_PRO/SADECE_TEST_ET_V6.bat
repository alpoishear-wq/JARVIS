@echo off
chcp 65001 >nul
cd /d "%~dp0"
python -m py_compile jarvis_ultra_v6.py
if %errorlevel% equ 0 (
  echo Kod testi BASARILI.
) else (
  echo Kod testinde HATA var.
)
pause
