@echo off
chcp 65001 >nul
title Jarvis Ultra V6 Neon Voice Pro
cd /d "%~dp0"
echo.
echo ===============================================
echo   JARVIS ULTRA V6 NEON VOICE PRO
echo ===============================================
echo.
echo Paketler kontrol ediliyor...
python -m pip install --upgrade pip
python -m pip install -r jarvis_ultra_v6_requirements.txt

echo.
echo Mikrofon hatasi alirsan:
echo python -m pip install pipwin
echo pipwin install pyaudio
echo.
echo Jarvis V6 baslatiliyor...
python jarvis_ultra_v6.py
pause
