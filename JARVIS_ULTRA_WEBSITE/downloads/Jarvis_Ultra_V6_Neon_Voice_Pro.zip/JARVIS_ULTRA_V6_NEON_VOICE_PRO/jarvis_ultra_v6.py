# -*- coding: utf-8 -*-
"""
Jarvis Ultra V6 Neon Voice Pro
Windows 10/11 için sade, modern, sesli bilgisayar asistanı.

Özellikler:
- Modern sade Tkinter arayüz
- Uygulama/oyun aç-kapat
- Hey Jarvis uyandırma kelimesi
- Oyun modu / çalışma modu
- Özel komut oluşturma
- Sistem durumu paneli
- Hatırlatıcı ve not sistemi
- Tema seçenekleri
- Premium sesli cevap ve konuşma öncesi özel ses efekti
- Offline gelişmiş sohbet veritabanı ve yerel hafıza
- Log ve hata kaydı

Not: Mikrofonla konuşma için PyAudio gerekir. Kurulum bat dosyası yardımcı olur.
"""

from __future__ import annotations

import datetime as _dt
import difflib
import json
import logging
import os
import platform
import re
import shutil
import subprocess
import sys
import threading
import time
import traceback
import tempfile
import random
import webbrowser
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

try:
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk
except Exception as exc:  # pragma: no cover
    print("Tkinter yüklenemedi:", exc)
    raise

# Opsiyonel modüller. Kurulu değilse uygulama yine açılır.
try:
    import speech_recognition as sr
except Exception:  # pragma: no cover
    sr = None

try:
    import pyautogui
except Exception:  # pragma: no cover
    pyautogui = None

try:
    import psutil
except Exception:  # pragma: no cover
    psutil = None

try:
    import pyttsx3
except Exception:  # pragma: no cover
    pyttsx3 = None

try:
    from plyer import notification
except Exception:  # pragma: no cover
    notification = None

try:
    import winsound
except Exception:  # pragma: no cover
    winsound = None

APP_NAME = "Jarvis Ultra V6"
BASE_DIR = Path(__file__).resolve().parent
CONFIG_PATH = BASE_DIR / "jarvis_config.json"
NOTES_PATH = BASE_DIR / "jarvis_notlar.txt"
LOG_PATH = BASE_DIR / "jarvis_v5.log"
CHAT_DB_PATH = BASE_DIR / "jarvis_chat_database.json"
MEMORY_PATH = BASE_DIR / "jarvis_memory.json"
SCREENSHOT_DIR = BASE_DIR / "ekran_goruntuleri"
SCREENSHOT_DIR.mkdir(exist_ok=True)

logging.basicConfig(
    filename=str(LOG_PATH),
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
    encoding="utf-8",
)

TURKISH_MAP = str.maketrans({
    "ç": "c", "ğ": "g", "ı": "i", "ö": "o", "ş": "s", "ü": "u",
    "Ç": "c", "Ğ": "g", "İ": "i", "I": "i", "Ö": "o", "Ş": "s", "Ü": "u",
})

OPEN_WORDS = {"ac", "baslat", "calistir", "gir", "giris", "oynat"}
CLOSE_WORDS = {"kapat", "kapa", "sonlandir", "cik", "cikis", "oldur", "bitir"}
SEARCH_WORDS = {"ara", "arama", "bul", "arat"}

THEMES = {
    "Neon Cyber": {
        "bg": "#050812",
        "panel": "#070d1d",
        "card": "#0d1730",
        "card2": "#132247",
        "text": "#f5fbff",
        "muted": "#8aa4c7",
        "accent": "#00e5ff",
        "accent2": "#b026ff",
        "danger": "#ff2e88",
        "warn": "#ffe66d",
        "border": "#1e4d87",
    },
    "Minimal Dark": {
        "bg": "#0f1117",
        "panel": "#171a23",
        "card": "#202432",
        "card2": "#252a3a",
        "text": "#f4f6fb",
        "muted": "#9aa4b2",
        "accent": "#7c5cff",
        "accent2": "#3ddc97",
        "danger": "#ff4d6d",
        "warn": "#ffbe0b",
        "border": "#2b3142",
    },
    "Police Blue": {
        "bg": "#071421",
        "panel": "#0d2238",
        "card": "#123250",
        "card2": "#183c5f",
        "text": "#f0f8ff",
        "muted": "#9cc3de",
        "accent": "#2d9cff",
        "accent2": "#2de2e6",
        "danger": "#ff4d6d",
        "warn": "#ffd166",
        "border": "#24527a",
    },
    "Matrix Green": {
        "bg": "#061008",
        "panel": "#0b1b0f",
        "card": "#102817",
        "card2": "#14341e",
        "text": "#e9ffe9",
        "muted": "#9fd6a4",
        "accent": "#00e676",
        "accent2": "#69f0ae",
        "danger": "#ff5252",
        "warn": "#ffee58",
        "border": "#235a30",
    },
    "Gaming Red": {
        "bg": "#13080b",
        "panel": "#230f15",
        "card": "#321820",
        "card2": "#3c1e28",
        "text": "#fff4f6",
        "muted": "#d8a8b4",
        "accent": "#ff335f",
        "accent2": "#ff8fab",
        "danger": "#ffbe0b",
        "warn": "#ffd166",
        "border": "#572b38",
    },
}

DEFAULT_CONFIG: Dict[str, Any] = {
    "settings": {
        "theme": "Neon Cyber",
        "wake_enabled": False,
        "wake_words": ["jarvis", "hey jarvis", "hey carvis", "asistan"],
        "awake_seconds": 12,
        "phrase_time_limit": 30,
        "listen_timeout": 8,
        "pause_threshold": 1.85,
        "energy_duration": 0.8,
        "voice_enabled": True,
        "voice_rate": 165,
        "voice_volume": 0.95,
        "voice_profile": "auto_premium",
        "tts_backend": "windows_sapi",
        "speak_chime_enabled": True,
        "chat_enabled": True,
        "auto_chat_fallback": True,
        "assistant_style": "karizmatik",
        "neon_effects": True,
        "user_display_name": "kanka",
        "confirm_dangerous_actions": True,
    },
    "apps": {
        "valorant": {
            "aliases": ["valorant", "valo", "vloranat", "valoran", "valörant"],
            "paths": [
                r"%USERPROFILE%\Desktop\VALORANT.lnk",
                r"C:\Riot Games\Riot Client\RiotClientServices.exe",
            ],
            "processes": ["VALORANT-Win64-Shipping.exe", "VALORANT.exe", "RiotClientServices.exe"],
            "arguments": ["--launch-product=valorant", "--launch-patchline=live"],
        },
        "gta 5": {
            "aliases": ["gta", "gta 5", "gta v", "grand theft auto", "gta bes"],
            "paths": [
                r"%USERPROFILE%\Desktop\Grand Theft Auto V.lnk",
                r"%USERPROFILE%\Desktop\GTA V.lnk",
            ],
            "processes": ["GTA5.exe", "PlayGTAV.exe", "GTAVLauncher.exe"],
            "arguments": [],
        },
        "fortnite": {
            "aliases": ["fortnite", "fortnayt", "fn", "fornayt"],
            "paths": [
                r"%USERPROFILE%\Desktop\Fortnite.lnk",
                r"C:\Program Files\Epic Games\Fortnite\FortniteGame\Binaries\Win64\FortniteLauncher.exe",
            ],
            "processes": ["FortniteClient-Win64-Shipping.exe", "FortniteLauncher.exe", "EpicGamesLauncher.exe"],
            "arguments": [],
        },
        "roblox": {
            "aliases": ["roblox", "robloğ", "roblo", "roblok", "roblox player"],
            "paths": [r"%USERPROFILE%\Desktop\Roblox.lnk"],
            "processes": ["RobloxPlayerBeta.exe", "RobloxPlayerLauncher.exe"],
            "arguments": [],
        },
        "steam": {
            "aliases": ["steam", "stim"],
            "paths": [r"C:\Program Files (x86)\Steam\steam.exe", r"%USERPROFILE%\Desktop\Steam.lnk"],
            "processes": ["steam.exe"],
            "arguments": [],
        },
        "epic games": {
            "aliases": ["epic", "epic games", "epik", "epik games"],
            "paths": [r"C:\Program Files (x86)\Epic Games\Launcher\Portal\Binaries\Win64\EpicGamesLauncher.exe"],
            "processes": ["EpicGamesLauncher.exe"],
            "arguments": [],
        },
        "discord": {
            "aliases": ["discord", "diskort", "discort"],
            "paths": [r"%LOCALAPPDATA%\Discord\Update.exe", r"%USERPROFILE%\Desktop\Discord.lnk"],
            "processes": ["Discord.exe", "Update.exe"],
            "arguments": ["--processStart", "Discord.exe"],
        },
        "chrome": {
            "aliases": ["chrome", "google chrome", "krom", "tarayici", "tarayıcı"],
            "paths": [r"C:\Program Files\Google\Chrome\Application\chrome.exe", r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"],
            "processes": ["chrome.exe"],
            "arguments": [],
        },
        "spotify": {
            "aliases": ["spotify", "spotifay", "müzik", "muzik"],
            "paths": [r"%APPDATA%\Spotify\Spotify.exe", r"%USERPROFILE%\Desktop\Spotify.lnk"],
            "processes": ["Spotify.exe"],
            "arguments": [],
        },
        "not defteri": {
            "aliases": ["not defteri", "notepad", "not", "defter"],
            "paths": ["notepad.exe"],
            "processes": ["notepad.exe"],
            "arguments": [],
        },
        "hesap makinesi": {
            "aliases": ["hesap makinesi", "hesapla", "calculator", "makine"],
            "paths": ["calc.exe"],
            "processes": ["CalculatorApp.exe", "calc.exe"],
            "arguments": [],
        },
    },
    "websites": {
        "youtube": {"aliases": ["youtube", "yutub", "you tube"], "url": "https://www.youtube.com"},
        "google": {"aliases": ["google", "gugil"], "url": "https://www.google.com"},
        "gmail": {"aliases": ["gmail", "mail", "e posta", "eposta"], "url": "https://mail.google.com"},
        "chatgpt": {"aliases": ["chatgpt", "chat gpt", "cet cipiti", "çetcipiti"], "url": "https://chatgpt.com"},
        "instagram": {"aliases": ["instagram", "insta"], "url": "https://www.instagram.com"},
        "twitch": {"aliases": ["twitch", "tiviç"], "url": "https://www.twitch.tv"},
        "netflix": {"aliases": ["netflix", "netfliks"], "url": "https://www.netflix.com"},
    },
    "scenarios": {
        "oyun modu": {
            "aliases": ["oyun modu", "game mode", "oyun modunu ac", "oyun icin hazirla"],
            "actions": [
                {"type": "open_app", "target": "discord"},
                {"type": "open_app", "target": "spotify"},
                {"type": "open_app", "target": "steam"},
                {"type": "notify", "target": "Oyun modu açıldı. İstersen arayüzden hangi oyunların açılacağını değiştirebilirsin."},
            ],
        },
        "çalışma modu": {
            "aliases": ["calisma modu", "çalışma modu", "ders modu", "is modu", "iş modu"],
            "actions": [
                {"type": "open_app", "target": "chrome"},
                {"type": "open_app", "target": "not defteri"},
                {"type": "reminder", "target": "45|Odak süren doldu, kısa mola ver."},
                {"type": "notify", "target": "Çalışma modu açıldı. 45 dakika odak hatırlatıcısı kuruldu."},
            ],
        },
    },
    "custom_commands": [],
    "first_run_done": False,
}


def normalize(text: str) -> str:
    if not text:
        return ""
    text = text.translate(TURKISH_MAP).lower().strip()
    replacements = {
        "vloranat": "valorant",
        "valörant": "valorant",
        "valoran": "valorant",
        "valo": "valorant",
        "gta bes": "gta 5",
        "gta beş": "gta 5",
        "gta v": "gta 5",
        "fortnayt": "fortnite",
        "fornayt": "fortnite",
        "fn": "fortnite",
        "robloğ": "roblox",
        "roblok": "roblox",
        "diskort": "discord",
        "spotifay": "spotify",
        "yutub": "youtube",
        "gugil": "google",
        "kapatirmisin": "kapat",
        "acarmisin": "ac",
        "acar misin": "ac",
        "kapatir misin": "kapat",
        "baslatir misin": "baslat",
    }
    for old, new in replacements.items():
        text = text.replace(old, new)
    text = re.sub(r"[^a-z0-9\s\/\-\.:%]", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def deep_merge(default: Dict[str, Any], current: Dict[str, Any]) -> Dict[str, Any]:
    result = dict(default)
    for key, value in current.items():
        if isinstance(value, dict) and isinstance(result.get(key), dict):
            result[key] = deep_merge(result[key], value)
        else:
            result[key] = value
    return result



DEFAULT_CHAT_DB: Dict[str, Any] = {
    "intents": [
        {
            "name": "selamlama",
            "patterns": ["selam", "merhaba", "sa", "jarvis", "hey jarvis", "gunaydin", "iyi aksamlar"],
            "responses": [
                "Buradayım kanka. Sistemi dinliyorum.",
                "Hazırım. Bugün bilgisayarı birlikte daha akıllı kullanacağız.",
                "Komut merkezindeyim. Ne yapıyoruz?"
            ],
        },
        {
            "name": "hal_hatir",
            "patterns": ["nasilsin", "iyi misin", "ne haber", "keyfin nasil"],
            "responses": [
                "İyiyim kanka. Sistem stabil, mikrofon aktif, komut bekliyorum.",
                "Gayet iyiyim. Sen söyle, oyun modu mu çalışma modu mu?",
                "Hazırım. Bugün hızlı, sakin ve net çalışıyoruz."
            ],
        },
        {
            "name": "kimlik",
            "patterns": ["sen kimsin", "adın ne", "adin ne", "kendini tanit", "ne ise yariyorsun"],
            "responses": [
                "Ben Jarvis Ultra V6. Bilgisayarını sesle yönetmek, uygulama açıp kapatmak, not almak, hatırlatmak ve sohbet etmek için tasarlandım.",
                "Ben senin masaüstü asistanınım. Komutları uygularım, sistemi takip ederim ve gerektiğinde konuşarak cevap veririm."
            ],
        },

        {
            "name": "profesyonel_oneri",
            "patterns": ["ne ekleyelim", "uygulamayi nasil gelistirelim", "profesyonel seviye", "uçar mi", "ozellik oner"],
            "responses": [
                "Profesyonel seviye için üç şey çok değerli: kurulum sihirbazı, sesli sohbet motoru ve kişisel komut profilleri. V6'da bunların altyapısı aktif.",
                "Bunu ürün gibi büyütmek için kullanıcıya özel modlar, tek tık kurulum, lisans sistemi ve hata çözme ekranı en kritik parçalar."
            ],
        },
        {
            "name": "oyun_destek",
            "patterns": ["oyuna hazirla", "fps", "ping", "lag", "oyun kasiyor", "bilgisayar kasiyor"],
            "responses": [
                "Oyun için önce gereksiz uygulamaları kapat, ping testi yap, sonra oyun modunu aç. İstersen oyun modunu aç komutunu kullanabilirsin.",
                "Kasarsa oyun modunu aç, temp temizle ve ping testi yap. Sistem durumunu da takip edebilirim."
            ],
        },
        {
            "name": "tesekkur",
            "patterns": ["tesekkur", "eyvallah", "sag ol", "sağ ol", "adamsin", "kralsin"],
            "responses": [
                "Her zaman kanka.",
                "Rica ederim. Sistemi hazır tutuyorum.",
                "Eyvallah. Bir sonraki komutu bekliyorum."
            ],
        },
        {
            "name": "motivasyon",
            "patterns": ["motive et", "motivasyon", "gaza getir", "modum dustu", "canim sikildi"],
            "responses": [
                "Kanka odağı bozmuyoruz. Küçük bir iş seç, bitir, sonra hız kendiliğinden gelir.",
                "Bugün mükemmel olmak zorunda değilsin. Sadece dünkünden bir tık daha düzenli olman yeter.",
                "Şu an yapman gereken tek şey başlamak. Gerisini sistemle birlikte toparlarız."
            ],
        },
        {
            "name": "bilgisayar_yavas",
            "patterns": ["bilgisayar yavas", "pc yavas", "kasma var", "bilgisayar kasiyor", "performans dusuk"],
            "responses": [
                "Önce sistem durumunu kontrol etmeni öneririm. İstersen 'sistem durumu nedir' de; CPU, RAM ve disk kullanımını söyleyeyim.",
                "Kasma varsa gereksiz uygulamaları kapatmak iyi olur. 'açtıklarımı kapat' veya 'oyun modunu aç' diyebilirsin.",
                "Performans için arka plandaki uygulamaları azalt, disk doluluğunu kontrol et ve oyun öncesi oyun modunu kullan."
            ],
        },
        {
            "name": "ozellik_oneri",
            "patterns": ["ne ekleyelim", "ozellik oner", "daha ne yapabilirsin", "profesyonel olsun", "uygulama ucsun"],
            "responses": [
                "Profesyonel seviye için en güçlü üçlü: özel komutlar, oyun/çalışma modları ve sesli sohbet. Bunlar V5 içinde hazır.",
                "Satış için kurulum sihirbazı, lisans sistemi, tema seçimi ve hata çözme ekranı çok değer katar.",
                "Bence sıradaki büyük adım: lisans anahtarı, otomatik güncelleme ve tek tık Windows kurulum dosyası."
            ],
        },
        {
            "name": "saka",
            "patterns": ["saka yap", "şaka yap", "espiri yap", "espri yap"],
            "responses": [
                "Bilgisayar neden doktora gitmiş? Çünkü Windows'u açılmıyormuş.",
                "Bir yazılımcı markete gitmiş; eşi 'bir ekmek al, yumurta varsa 10 tane al' demiş. Eve 10 ekmekle dönmüş.",
                "Ben şaka yaparım ama mavi ekran yapmam. O işi Windows'a bıraktım."
            ],
        },
    ],
    "fallbacks": [
        "Bunu sohbet olarak algıladım ama tam emin değilim. İstersen daha kısa bir komutla tekrar söyleyebilirsin.",
        "Anladığım kadarıyla konuşmak istiyorsun. Komut vermek istersen 'yardım' diyebilirsin.",
        "Bunu tam çözemedim kanka. Ama uygulama açma, kapatma, sistem durumu, not, hatırlatıcı ve sohbet tarafında hazırım.",
    ],
}


def load_json_file(path: Path, default: Any) -> Any:
    try:
        if path.exists():
            return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        logging.exception("JSON okunamadı: %s", path)
    try:
        path.write_text(json.dumps(default, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception:
        logging.exception("JSON yazılamadı: %s", path)
    return default


def save_json_file(path: Path, data: Any) -> None:
    try:
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception:
        logging.exception("JSON kaydedilemedi: %s", path)

def load_config() -> Dict[str, Any]:
    if CONFIG_PATH.exists():
        try:
            with CONFIG_PATH.open("r", encoding="utf-8") as f:
                user_cfg = json.load(f)
            return deep_merge(DEFAULT_CONFIG, user_cfg)
        except Exception:
            logging.exception("Config okunamadı, varsayılan kullanılacak")
    save_config(DEFAULT_CONFIG)
    return json.loads(json.dumps(DEFAULT_CONFIG, ensure_ascii=False))


def save_config(config: Dict[str, Any]) -> None:
    with CONFIG_PATH.open("w", encoding="utf-8") as f:
        json.dump(config, f, ensure_ascii=False, indent=2)


def expand_path(path: str) -> str:
    return os.path.expandvars(os.path.expanduser(path))


def safe_exists(path: str) -> bool:
    if path.lower().endswith(".exe") and os.path.basename(path).lower() in {"notepad.exe", "calc.exe"}:
        return True
    return Path(expand_path(path)).exists()


@dataclass
class MatchResult:
    name: Optional[str]
    score: float
    data: Optional[Dict[str, Any]] = None


class JarvisEngine:
    def __init__(self, ui: "JarvisUI"):
        self.ui = ui
        self.config = load_config()
        self.running = False
        self.listen_thread: Optional[threading.Thread] = None
        self.recognizer = None
        self.awake_until = 0.0
        self._tts_engine = None
        self._tts_lock = threading.Lock()
        self.chat_db = load_json_file(CHAT_DB_PATH, DEFAULT_CHAT_DB)
        self.memory = load_json_file(MEMORY_PATH, {"facts": [], "history": []})
        self._init_tts()

    # -------------------- GENEL YARDIMCILAR --------------------
    def log(self, message: str, level: str = "info") -> None:
        getattr(logging, level, logging.info)(message)
        self.ui.append_log(message)

    def _init_tts(self) -> None:
        # V6: Konuşmama sorununu azaltmak için iki motor var.
        # 1) Windows SAPI / PowerShell: Varsayılan ve en stabil yol.
        # 2) pyttsx3: Alternatif motor. Kuruluysa yedekte tutulur.
        if pyttsx3 is None:
            self._tts_engine = None
            return
        try:
            self._tts_engine = pyttsx3.init()
            settings = self.config["settings"]
            self._tts_engine.setProperty("rate", int(settings.get("voice_rate", 165)))
            self._tts_engine.setProperty("volume", float(settings.get("voice_volume", 0.95)))
            self._select_premium_voice()
        except Exception:
            logging.exception("pyttsx3 TTS başlatılamadı; Windows SAPI fallback kullanılacak")
            self._tts_engine = None

    def _select_premium_voice(self) -> None:
        """Windows'taki en uygun sesi otomatik seçer. Türkçe ses varsa onu, yoksa en tok/temiz sesi seçer."""
        if self._tts_engine is None:
            return
        try:
            voices = self._tts_engine.getProperty("voices") or []
            preferred = [
                "tolga", "emel", "turkish", "tr-tr", "zira", "david", "mark", "guy", "natural", "desktop"
            ]
            best = None
            best_score = -1
            for v in voices:
                data = f"{getattr(v, 'id', '')} {getattr(v, 'name', '')}".lower()
                score = 0
                for i, key in enumerate(preferred):
                    if key in data:
                        score += 100 - i * 5
                # Erkek/tok ses isimleri varsa karizmatik profile daha uygun oluyor.
                if any(k in data for k in ["tolga", "david", "mark", "guy"]):
                    score += 12
                if score > best_score:
                    best_score = score
                    best = v
            if best is not None and best_score > 0:
                self._tts_engine.setProperty("voice", best.id)
                self.log(f"Seçilen ses: {getattr(best, 'name', best.id)}")
        except Exception:
            logging.exception("Ses seçimi başarısız")

    def _play_speak_chime(self) -> None:
        if not self.config["settings"].get("speak_chime_enabled", True):
            return
        if winsound is None:
            return
        try:
            # Kısa, premium, rahatsız etmeyen bildirim efekti.
            for freq, dur in [(520, 45), (740, 48), (980, 62), (1320, 72)]:
                winsound.Beep(freq, dur)
        except Exception:
            try:
                winsound.MessageBeep()
            except Exception:
                pass

    def _speak_with_windows_sapi(self, text: str) -> bool:
        """Windows'un yerleşik SAPI ses motorunu PowerShell üzerinden kullanır.
        Pyttsx3 bazı bilgisayarlarda sessiz kalabildiği için V6'da varsayılan çözüm budur.
        """
        if platform.system().lower() != "windows":
            return False
        try:
            rate = int(self.config.get("settings", {}).get("voice_rate", 165))
            # System.Speech rate -10/+10 aralığında. Uygulama hızını oraya ölçekle.
            sapi_rate = max(-4, min(3, int((rate - 165) / 20)))
            volume = int(float(self.config.get("settings", {}).get("voice_volume", 0.95)) * 100)
            safe_text = str(text).replace("'", "''")
            ps = (
                "Add-Type -AssemblyName System.Speech; "
                "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer; "
                f"$s.Rate = {sapi_rate}; $s.Volume = {max(0, min(100, volume))}; "
                "$voices = $s.GetInstalledVoices(); "
                "$picked = $null; "
                "foreach($v in $voices){ $n=$v.VoiceInfo.Name; $c=$v.VoiceInfo.Culture.Name; "
                "if($c -like 'tr-*' -or $n -match 'Tolga|Emel|Turkish'){ $picked=$n; break } } "
                "if($picked -ne $null){ $s.SelectVoice($picked) } "
                f"$s.Speak('{safe_text}');"
            )
            flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
            subprocess.Popen(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps], creationflags=flags)
            return True
        except Exception:
            logging.exception("Windows SAPI konuşma hatası")
            return False

    def _speak_with_pyttsx3(self, text: str) -> bool:
        if self._tts_engine is None:
            return False
        try:
            self._tts_engine.say(text)
            self._tts_engine.runAndWait()
            return True
        except Exception:
            logging.exception("pyttsx3 konuşma hatası")
            return False

    def speak(self, text: str) -> None:
        self.log(f"Jarvis: {text}")
        try:
            if hasattr(self.ui, "add_chat_message"):
                self.ui.add_chat_message("Jarvis", text)
        except Exception:
            pass
        if not self.config["settings"].get("voice_enabled", True):
            return

        def _run():
            try:
                with self._tts_lock:
                    self._play_speak_chime()
                    backend = self.config.get("settings", {}).get("tts_backend", "windows_sapi")
                    ok = False
                    if backend == "windows_sapi":
                        ok = self._speak_with_windows_sapi(text)
                        if not ok:
                            ok = self._speak_with_pyttsx3(text)
                    else:
                        ok = self._speak_with_pyttsx3(text)
                        if not ok:
                            ok = self._speak_with_windows_sapi(text)
                    if not ok:
                        self.log("Ses motoru çalışmadı. Ayarlar > Sesli cevap açık mı ve Windows sesleri yüklü mü kontrol et.", "error")
            except Exception:
                logging.exception("Konuşma hatası")
        threading.Thread(target=_run, daemon=True).start()

    def voice_diagnostics(self) -> None:
        backend = self.config.get("settings", {}).get("tts_backend", "windows_sapi")
        py = "kurulu" if pyttsx3 is not None else "kurulu değil"
        win = "uygun" if platform.system().lower() == "windows" else "Windows değil"
        self.speak(f"Ses durumu: motor {backend}. Pyttsx3 {py}. Windows SAPI {win}. Sesli cevap açıksa şimdi konuşuyor olmam gerekiyor.")

    def repair_voice(self) -> None:
        self.config.setdefault("settings", {})["voice_enabled"] = True
        self.config.setdefault("settings", {})["speak_chime_enabled"] = True
        self.config.setdefault("settings", {})["tts_backend"] = "windows_sapi"
        self.save()
        self.speak("Ses sistemi Windows SAPI moduna alındı. Bu mod genelde en stabil konuşma modudur.")

    def notify(self, title: str, message: str) -> None:
        if notification:
            try:
                notification.notify(title=title, message=message, timeout=6, app_name=APP_NAME)
                return
            except Exception:
                logging.exception("Bildirim hatası")
        self.log(f"Bildirim: {title} - {message}")

    def save(self) -> None:
        save_config(self.config)

    # -------------------- EŞLEŞTİRME --------------------
    def _best_match_collection(self, text: str, collection_key: str) -> MatchResult:
        normalized = normalize(text)
        best_name = None
        best_score = 0.0
        best_data = None
        collection = self.config.get(collection_key, {})
        for name, data in collection.items():
            aliases = [name] + data.get("aliases", [])
            for alias in aliases:
                n_alias = normalize(alias)
                if not n_alias:
                    continue
                if n_alias in normalized:
                    score = min(1.0, 0.85 + len(n_alias) / max(20, len(normalized)))
                else:
                    # Her kelimeyi ve kısa varyasyonları karşılaştır.
                    score = difflib.SequenceMatcher(None, normalized, n_alias).ratio()
                    words = normalized.split()
                    if words:
                        word_scores = [difflib.SequenceMatcher(None, w, n_alias).ratio() for w in words]
                        score = max(score, max(word_scores) * 0.78)
                if score > best_score:
                    best_name, best_score, best_data = name, score, data
        return MatchResult(best_name, best_score, best_data)

    def match_app(self, text: str) -> MatchResult:
        return self._best_match_collection(text, "apps")

    def match_website(self, text: str) -> MatchResult:
        return self._best_match_collection(text, "websites")

    def match_scenario(self, text: str) -> MatchResult:
        return self._best_match_collection(text, "scenarios")

    def command_has_any(self, text: str, words: set[str]) -> bool:
        parts = set(normalize(text).split())
        return bool(parts & words)

    # -------------------- DİNLEME --------------------
    def calibrate(self) -> None:
        if sr is None:
            self.speak("Speech Recognition paketi kurulu değil.")
            return
        try:
            r = sr.Recognizer()
            with sr.Microphone() as source:
                self.ui.set_status("Kalibrasyon", "Mikrofon ortam sesi ölçülüyor...")
                self.log("Mikrofon kalibrasyonu başladı.")
                r.adjust_for_ambient_noise(source, duration=1.5)
                self.recognizer = r
            self.ui.set_status("Hazır", "Kalibrasyon tamamlandı")
            self.speak("Mikrofon kalibrasyonu tamamlandı.")
        except Exception as exc:
            self.ui.set_status("Hata", "Mikrofon kalibrasyonu başarısız")
            self.log(f"Mikrofon kalibrasyon hatası: {exc}", "error")
            self.speak("Mikrofon kalibrasyonu başarısız. PyAudio veya mikrofon iznini kontrol et.")

    def start_listening(self) -> None:
        if self.running:
            return
        if sr is None:
            self.speak("Speech Recognition kurulu değil. Kurulum dosyasını yeniden çalıştır.")
            return
        self.running = True
        self.listen_thread = threading.Thread(target=self._listen_loop, daemon=True)
        self.listen_thread.start()
        self.ui.set_status("Dinliyor", "Sesli komut aktif")
        self.speak("Dinleme başlatıldı.")

    def stop_listening(self) -> None:
        self.running = False
        self.ui.set_status("Beklemede", "Dinleme durdu")
        self.log("Dinleme durduruldu.")

    def _make_recognizer(self):
        r = sr.Recognizer()
        s = self.config["settings"]
        r.dynamic_energy_threshold = True
        r.pause_threshold = float(s.get("pause_threshold", 1.35))
        r.non_speaking_duration = max(0.5, float(s.get("pause_threshold", 1.35)) / 2)
        return r

    def _listen_loop(self) -> None:
        try:
            r = self.recognizer or self._make_recognizer()
            self.recognizer = r
            with sr.Microphone() as source:
                try:
                    r.adjust_for_ambient_noise(source, duration=float(self.config["settings"].get("energy_duration", 0.8)))
                except Exception:
                    pass
                while self.running:
                    settings = self.config["settings"]
                    r.pause_threshold = float(settings.get("pause_threshold", 1.35))
                    try:
                        self.ui.set_status("Dinliyor", "Komut bekleniyor...")
                        audio = r.listen(
                            source,
                            timeout=float(settings.get("listen_timeout", 6)),
                            phrase_time_limit=float(settings.get("phrase_time_limit", 20)),
                        )
                        self.ui.set_status("Çözümlüyor", "Ses yazıya çevriliyor...")
                        text = r.recognize_google(audio, language="tr-TR")
                        text = text.strip()
                        if text:
                            self.log(f"Duyulan: {text}")
                            self.ui.set_last_heard(text)
                            self._handle_wake_and_execute(text)
                    except sr.WaitTimeoutError:
                        continue
                    except sr.UnknownValueError:
                        self.log("Ses anlaşılamadı.")
                        continue
                    except sr.RequestError as exc:
                        self.log(f"Google konuşma servisi hatası: {exc}", "error")
                        self.speak("Ses tanıma servisine ulaşılamıyor. İnterneti kontrol et.")
                        time.sleep(2)
                    except Exception as exc:
                        self.log(f"Dinleme hatası: {exc}", "error")
                        logging.error(traceback.format_exc())
                        time.sleep(1)
        except Exception as exc:
            self.running = False
            self.ui.set_status("Hata", "Mikrofon başlatılamadı")
            self.log(f"Mikrofon genel hata: {exc}", "error")
            self.speak("Mikrofon başlatılamadı. PyAudio kurulumu veya Windows mikrofon iznini kontrol et.")

    def _handle_wake_and_execute(self, text: str) -> None:
        settings = self.config["settings"]
        n_text = normalize(text)
        if settings.get("wake_enabled", False):
            wake_words = [normalize(w) for w in settings.get("wake_words", [])]
            found_wake = None
            for wake in wake_words:
                if wake and wake in n_text:
                    found_wake = wake
                    break
            if found_wake:
                self.awake_until = time.time() + float(settings.get("awake_seconds", 12))
                command = n_text.replace(found_wake, "", 1).strip()
                if not command:
                    self.speak("Dinliyorum.")
                    return
                self.execute_command(command, original=text)
                return
            if time.time() <= self.awake_until:
                self.execute_command(text, original=text)
                return
            self.log("Uyandırma kelimesi yok, komut yok sayıldı.")
            return
        self.execute_command(text, original=text)

    # -------------------- KOMUT YÜRÜTME --------------------
    def execute_command(self, command: str, original: Optional[str] = None) -> None:
        raw = original or command
        text = normalize(command)
        if not text:
            return
        self.log(f"Komut işleniyor: {raw}")

        # Önce özel komutlar.
        if self._run_custom_command(text):
            return

        # Yardım
        if any(w in text for w in ["yardim", "komut listesi", "neler yapabilirsin", "ne yapabilirsin"]):
            self.show_help()
            return

        # Sohbet ve ses özel komutları
        if "ses testi" in text or "konusma testi" in text or "sesini test et" in text:
            self.speak("Ses testi başarılı. Jarvis Ultra V6 premium ses motoru aktif.")
            return
        if "ses durumu" in text or "ses sistemi" in text or "tts durumu" in text:
            self.voice_diagnostics()
            return
        if "konusmuyor" in text or "ses motorunu duzelt" in text or "sesi duzelt" in text:
            self.repair_voice()
            return
        if "windows ses motoru" in text or "sapi motoru" in text:
            self.config.setdefault("settings", {})["tts_backend"] = "windows_sapi"
            self.save()
            self.speak("Windows ses motoruna geçtim.")
            return
        if "pyttsx3 motoru" in text:
            self.config.setdefault("settings", {})["tts_backend"] = "pyttsx3"
            self.save()
            self.speak("Pyttsx3 ses motoruna geçtim.")
            return
        if "sohbet modu ac" in text or "sohbeti ac" in text:
            self.config.setdefault("settings", {})["chat_enabled"] = True
            self.save()
            self.speak("Sohbet modu aktif.")
            return
        if "sohbet modu kapat" in text or "sohbeti kapat" in text:
            self.config.setdefault("settings", {})["chat_enabled"] = False
            self.save()
            self.speak("Sohbet modu kapatıldı.")
            return

        # Not alma
        if text.startswith("not al") or text.startswith("not et") or text.startswith("kaydet"):
            note = re.sub(r"^(not al|not et|kaydet)\s*", "", text).strip()
            self.take_note(note or raw)
            return

        if "notlarimi ac" in text or "notlari ac" in text or "notlarimi goster" in text:
            self.open_notes()
            return

        # Hatırlatıcı
        if "hatirlat" in text or "hatirlatici" in text:
            if self._parse_reminder(text):
                return

        # Sistem durumu
        if any(p in text for p in ["sistem durumu", "ram", "cpu", "islemci", "pil durumu", "internet var mi"]):
            self.report_system_status()
            return

        # Ekran görüntüsü
        if "ekran goruntusu" in text or "screenshot" in text or "ekran resmi" in text:
            self.take_screenshot()
            return

        # Klasör açma
        if "indirilenleri ac" in text or "downloads ac" in text:
            self.open_folder(Path.home() / "Downloads")
            return
        if "masaustunu ac" in text or "masaustu ac" in text:
            self.open_folder(Path.home() / "Desktop")
            return
        if "jarvis klasorunu ac" in text or "program klasorunu ac" in text:
            self.open_folder(BASE_DIR)
            return

        # V6 üretkenlik ve bakım komutları
        if "panoyu oku" in text or "clipboard oku" in text:
            self.read_clipboard()
            return
        if text.startswith("panoya kopyala") or text.startswith("kopyala"):
            self.write_clipboard(raw)
            return
        if "ping testi" in text or "internet testi" in text:
            self.ping_test()
            return
        if "temp temizle" in text or "gecici dosyalari temizle" in text or "gereksiz dosyalari temizle" in text:
            self.clean_temp_files()
            return
        if "acik uygulamalari listele" in text or "calisan uygulamalari listele" in text:
            self.list_running_apps()
            return
        if "baslangica ekle" in text or "windows acilinca baslat" in text:
            self.add_to_startup()
            return
        if "baslangictan cikar" in text or "otomatik baslamayi kapat" in text:
            self.remove_from_startup()
            return

        # Ses kontrolü
        if "sesi ac" in text or "ses ac" in text:
            self.adjust_volume("up")
            return
        if "sesi kis" in text or "ses kis" in text:
            self.adjust_volume("down")
            return
        if "sessize al" in text or "sesi kapat" in text:
            self.adjust_volume("mute")
            return

        # Sistem güç komutları
        if "aktif pencere" in text and ("kapat" in text or "kapa" in text):
            self.close_active_window()
            return
        if "actiklarimi kapat" in text or "açtıklarımı kapat" in command.lower() or "son actiklarimi kapat" in text:
            self.close_known_user_apps()
            return
        if "kapatmayi iptal" in text or "kapatma iptal" in text:
            self.cancel_shutdown()
            return
        if "bilgisayari kilitle" in text or "ekrani kilitle" in text:
            self.lock_pc()
            return
        if "yeniden baslat" in text or "restart" in text:
            self.restart_pc()
            return
        if "bilgisayari kapat" in text or "pc kapat" in text or "sistemi kapat" in text:
            self.shutdown_pc()
            return
        if "uyku modu" in text or "uykuya al" in text:
            self.sleep_pc()
            return
        if "jarvis kapat" in text or "programi kapat" in text:
            self.speak("Görüşürüz.")
            self.ui.after(700, self.ui.destroy)
            return

        # Senaryo/mod
        scenario = self.match_scenario(text)
        if scenario.name and scenario.score >= 0.68 and ("mod" in text or "hazirla" in text or "baslat" in text or "ac" in text):
            self.run_scenario(scenario.name)
            return

        # Web arama
        if "youtube" in text and self.command_has_any(text, SEARCH_WORDS):
            q = text.replace("youtube", "").replace("da", "").replace("de", "")
            for w in SEARCH_WORDS:
                q = q.replace(w, "")
            self.search_web(q.strip(), provider="youtube")
            return
        if "google" in text and self.command_has_any(text, SEARCH_WORDS):
            q = text.replace("google", "")
            for w in SEARCH_WORDS:
                q = q.replace(w, "")
            self.search_web(q.strip(), provider="google")
            return

        # Web site açma
        if self.command_has_any(text, OPEN_WORDS):
            site = self.match_website(text)
            app = self.match_app(text)
            if site.name and site.score >= 0.72 and (not app.name or site.score >= app.score):
                self.open_website(site.name)
                return
            if app.name and app.score >= 0.62:
                self.open_app(app.name)
                return

        # Uygulama kapatma
        if self.command_has_any(text, CLOSE_WORDS):
            app = self.match_app(text)
            if app.name and app.score >= 0.55:
                self.close_app(app.name)
                return
            site = self.match_website(text)
            if site.name and site.score >= 0.68:
                self.close_browser_hint(site.name)
                return

        # Basit hesaplama
        if text.startswith("hesapla"):
            self.simple_calculate(text.replace("hesapla", "", 1).strip())
            return

        # Sohbet fallback: komut değilse insan gibi cevap vermeyi dene.
        if self.chat_reply(raw):
            return

        # Fallback
        closest_app = self.match_app(text)
        closest_site = self.match_website(text)
        suggestion = closest_app.name if closest_app.score >= closest_site.score else closest_site.name
        if suggestion and max(closest_app.score, closest_site.score) > 0.45:
            self.speak(f"Komutu tam anlayamadım. {suggestion} ile ilgili bir şey mi istedin?")
        else:
            if self.config.get("settings", {}).get("auto_chat_fallback", True):
                self.fallback_chat(raw)
            else:
                self.speak("Komutu tam anlayamadım. Yardım dersen komutları gösterebilirim.")


    # -------------------- V6 EK PROFESYONEL ÖZELLİKLER --------------------
    def read_clipboard(self) -> None:
        try:
            data = self.ui.clipboard_get()
            if data.strip():
                self.speak("Panoda şunlar var: " + data[:400])
            else:
                self.speak("Pano boş görünüyor.")
        except Exception:
            self.speak("Panoyu okuyamadım. Pano boş olabilir.")

    def write_clipboard(self, raw: str) -> None:
        try:
            text = re.sub(r"^(panoya kopyala|kopyala)\s*", "", raw, flags=re.IGNORECASE).strip()
            if not text:
                self.speak("Neyi panoya kopyalayacağımı anlayamadım.")
                return
            self.ui.clipboard_clear()
            self.ui.clipboard_append(text)
            self.speak("Metni panoya kopyaladım.")
        except Exception:
            self.speak("Panoya yazamadım.")

    def ping_test(self) -> None:
        def _run():
            try:
                target = "8.8.8.8"
                flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
                cp = subprocess.run(["ping", "-n", "4", target], capture_output=True, text=True, creationflags=flags, timeout=12)
                out = (cp.stdout or cp.stderr or "")
                m = re.search(r"Average = (\d+)ms|Ortalama = (\d+)ms", out, re.IGNORECASE)
                avg = next((g for g in (m.groups() if m else []) if g), None)
                if avg:
                    self.speak(f"Ping testi tamamlandı. Ortalama gecikme {avg} milisaniye.")
                elif cp.returncode == 0:
                    self.speak("Ping testi tamamlandı. İnternet bağlantısı var görünüyor.")
                else:
                    self.speak("Ping testi başarısız. İnternet bağlantısını kontrol et.")
            except Exception:
                self.speak("Ping testi yapılamadı.")
        threading.Thread(target=_run, daemon=True).start()

    def clean_temp_files(self) -> None:
        def _run():
            cleaned = 0
            skipped = 0
            temp_dirs = [Path(tempfile.gettempdir())]
            for root in temp_dirs:
                if not root.exists():
                    continue
                for item in list(root.iterdir())[:2000]:
                    try:
                        if item.is_file() or item.is_symlink():
                            item.unlink()
                            cleaned += 1
                        elif item.is_dir():
                            shutil.rmtree(item, ignore_errors=True)
                            cleaned += 1
                    except Exception:
                        skipped += 1
            self.speak(f"Geçici dosya temizliği bitti. {cleaned} öğe temizlendi, {skipped} öğe kullanımda olduğu için atlandı.")
        threading.Thread(target=_run, daemon=True).start()

    def list_running_apps(self) -> None:
        if psutil is None:
            self.speak("Psutil kurulu değil, çalışan uygulamaları listeleyemiyorum.")
            return
        try:
            names = []
            for p in psutil.process_iter(["name"]):
                n = (p.info.get("name") or "").strip()
                if n and n.lower() not in {"system", "registry", "idle"}:
                    names.append(n)
            common = sorted(set(names))[:12]
            if common:
                self.speak("Bazı çalışan uygulamalar: " + ", ".join(common))
            else:
                self.speak("Çalışan uygulama listesi boş görünüyor.")
        except Exception:
            self.speak("Çalışan uygulamaları okuyamadım.")

    def add_to_startup(self) -> None:
        if platform.system().lower() != "windows":
            self.speak("Başlangıca ekleme sadece Windows için hazırlandı.")
            return
        try:
            startup = Path(os.environ.get("APPDATA", "")) / "Microsoft" / "Windows" / "Start Menu" / "Programs" / "Startup"
            startup.mkdir(parents=True, exist_ok=True)
            bat = startup / "JarvisUltraV6.bat"
            bat.write_text(f'@echo off\ncd /d "{BASE_DIR}"\npython "{Path(__file__).name}"\n', encoding="utf-8")
            self.speak("Jarvis Windows başlangıcına eklendi.")
        except Exception:
            self.speak("Başlangıca ekleyemedim. Yönetici izni gerekebilir.")

    def remove_from_startup(self) -> None:
        try:
            startup = Path(os.environ.get("APPDATA", "")) / "Microsoft" / "Windows" / "Start Menu" / "Programs" / "Startup"
            bat = startup / "JarvisUltraV6.bat"
            if bat.exists():
                bat.unlink()
                self.speak("Jarvis başlangıçtan çıkarıldı.")
            else:
                self.speak("Başlangıçta Jarvis kaydı bulamadım.")
        except Exception:
            self.speak("Başlangıç kaydını kaldıramadım.")

    # -------------------- SOHBET MOTORU --------------------
    def remember_fact(self, fact: str) -> None:
        fact = fact.strip()
        if not fact:
            self.speak("Neyi hatırlamam gerektiğini anlayamadım.")
            return
        item = {"time": _dt.datetime.now().strftime("%Y-%m-%d %H:%M"), "fact": fact}
        self.memory.setdefault("facts", []).append(item)
        save_json_file(MEMORY_PATH, self.memory)
        self.speak("Tamam, bunu yerel hafızaya kaydettim.")

    def open_chat_database(self) -> None:
        try:
            if not CHAT_DB_PATH.exists():
                save_json_file(CHAT_DB_PATH, DEFAULT_CHAT_DB)
            os.startfile(str(CHAT_DB_PATH))  # type: ignore[attr-defined]
            self.speak("Sohbet veritabanını açıyorum.")
        except Exception:
            self.speak("Sohbet veritabanı açılamadı.")

    def open_memory_file(self) -> None:
        try:
            if not MEMORY_PATH.exists():
                save_json_file(MEMORY_PATH, self.memory)
            os.startfile(str(MEMORY_PATH))  # type: ignore[attr-defined]
            self.speak("Yerel hafıza dosyasını açıyorum.")
        except Exception:
            self.speak("Hafıza dosyası açılamadı.")

    def chat_reply(self, text: str) -> bool:
        if not self.config.get("settings", {}).get("chat_enabled", True):
            return False
        n_text = normalize(text)
        if not n_text:
            return False

        if n_text.startswith("beni hatirla") or n_text.startswith("bunu hatirla") or n_text.startswith("hafizana al"):
            fact = re.sub(r"^(beni hatirla|bunu hatirla|hafizana al)\s*", "", n_text).strip()
            self.remember_fact(fact)
            return True

        if "sohbet veritabani" in n_text and ("ac" in n_text or "goster" in n_text):
            self.open_chat_database()
            return True

        if "hafiza" in n_text and ("ac" in n_text or "goster" in n_text):
            self.open_memory_file()
            return True

        if "beni taniyor musun" in n_text or "hakkimda ne biliyorsun" in n_text or "benim hakkimda" in n_text:
            facts = self.memory.get("facts", [])[-5:]
            if not facts:
                self.speak("Henüz yerel hafızamda seninle ilgili kayıtlı bilgi yok. 'Beni hatırla ...' diye bir bilgi kaydedebilirsin.")
            else:
                summary = "; ".join(f.get("fact", "") for f in facts if f.get("fact"))
                self.speak("Yerel hafızamda şunlar var: " + summary)
            return True

        # Saat/tarih gibi konuşma sorularına hızlı cevap.
        if "saat kac" in n_text or "saat kaç" in text.lower():
            self.speak("Saat " + _dt.datetime.now().strftime("%H:%M"))
            return True
        if "bugun tarih" in n_text or "tarih ne" in n_text:
            self.speak("Bugünün tarihi " + _dt.datetime.now().strftime("%d.%m.%Y"))
            return True

        best_response = None
        best_score = 0.0
        for intent in self.chat_db.get("intents", []):
            for pat in intent.get("patterns", []):
                p = normalize(pat)
                if not p:
                    continue
                if p in n_text:
                    score = 0.92 + min(0.07, len(p) / 100)
                else:
                    score = difflib.SequenceMatcher(None, p, n_text).ratio()
                if score > best_score:
                    responses = intent.get("responses", [])
                    if responses:
                        idx = int(time.time()) % len(responses)
                        best_response = responses[idx]
                        best_score = score
        if best_response and best_score >= 0.62:
            self._save_chat_history(text, best_response)
            self.speak(best_response)
            return True
        return False

    def fallback_chat(self, text: str) -> None:
        fallbacks = self.chat_db.get("fallbacks", DEFAULT_CHAT_DB["fallbacks"])
        idx = int(time.time()) % max(1, len(fallbacks))
        response = fallbacks[idx]
        self._save_chat_history(text, response)
        self.speak(response)

    def _save_chat_history(self, user_text: str, assistant_text: str) -> None:
        try:
            hist = self.memory.setdefault("history", [])
            hist.append({
                "time": _dt.datetime.now().strftime("%Y-%m-%d %H:%M"),
                "user": user_text,
                "jarvis": assistant_text,
            })
            del hist[:-60]
            save_json_file(MEMORY_PATH, self.memory)
        except Exception:
            logging.exception("Sohbet geçmişi kaydedilemedi")

    def _run_custom_command(self, text: str) -> bool:
        commands = self.config.get("custom_commands", [])
        for item in commands:
            trigger = normalize(item.get("trigger", ""))
            if not trigger:
                continue
            if trigger in text or difflib.SequenceMatcher(None, trigger, text).ratio() > 0.86:
                self.log(f"Özel komut çalışıyor: {item.get('trigger')}")
                actions = item.get("actions", [])
                for action in actions:
                    self._run_action(action)
                self.speak(f"Özel komut çalıştı: {item.get('trigger')}")
                return True
        return False

    def _run_action(self, action: Dict[str, str]) -> None:
        typ = action.get("type")
        target = action.get("target", "")
        if typ == "open_app":
            self.open_app(target)
        elif typ == "close_app":
            self.close_app(target)
        elif typ == "open_url":
            webbrowser.open(target)
        elif typ == "search_google":
            self.search_web(target, "google")
        elif typ == "screenshot":
            self.take_screenshot()
        elif typ == "system_status":
            self.report_system_status()
        elif typ == "reminder":
            # target: "dakika|mesaj"
            parts = target.split("|", 1)
            if len(parts) == 2 and parts[0].strip().isdigit():
                self.set_reminder(int(parts[0].strip()), parts[1].strip())
        elif typ == "notify":
            self.notify(APP_NAME, target)
            self.speak(target)

    # -------------------- UYGULAMA / WEB --------------------
    def open_app(self, app_name: str) -> None:
        app = self.config.get("apps", {}).get(app_name)
        if not app:
            self.speak(f"{app_name} uygulaması kayıtlı değil.")
            return
        paths = app.get("paths", [])
        args = app.get("arguments", [])
        for raw_path in paths:
            path = expand_path(raw_path)
            try:
                if raw_path.lower().startswith("http"):
                    webbrowser.open(raw_path)
                    self.speak(f"{app_name} açılıyor.")
                    return
                if safe_exists(path):
                    if path.lower().endswith(".lnk"):
                        os.startfile(path)  # type: ignore[attr-defined]
                    else:
                        if args and Path(path).name.lower() not in {"notepad.exe", "calc.exe"}:
                            subprocess.Popen([path] + list(args), shell=False)
                        else:
                            subprocess.Popen([path], shell=False)
                    self.speak(f"{app_name} açılıyor.")
                    return
            except Exception as exc:
                self.log(f"{app_name} açılamadı {path}: {exc}", "error")
        self.speak(f"{app_name} yolu bulunamadı. Uygulamalar bölümünden doğru exe veya kısayolu seç.")

    def close_app(self, app_name: str) -> None:
        app = self.config.get("apps", {}).get(app_name)
        if not app:
            self.speak(f"{app_name} uygulaması kayıtlı değil.")
            return
        processes = app.get("processes", [])
        if not processes:
            # Path'ten process adı çıkar.
            processes = [Path(expand_path(p)).name for p in app.get("paths", []) if Path(expand_path(p)).suffix.lower() == ".exe"]
        killed = 0
        for proc in processes:
            if not proc:
                continue
            try:
                result = subprocess.run(["taskkill", "/F", "/IM", proc], capture_output=True, text=True, shell=False)
                if result.returncode == 0:
                    killed += 1
                    self.log(f"Kapatıldı: {proc}")
            except Exception as exc:
                self.log(f"Kapatma hatası {proc}: {exc}", "error")
        if killed:
            self.speak(f"{app_name} kapatıldı.")
        else:
            self.speak(f"{app_name} açık görünmüyor ya da işlem adı farklı. Uygulama ayarından process adını kontrol et.")

    def close_known_user_apps(self) -> None:
        targets = ["valorant", "gta 5", "fortnite", "roblox", "spotify", "discord", "steam", "epic games"]
        for name in targets:
            self.close_app(name)
        self.speak("Kayıtlı oyun ve eğlence uygulamalarını kapatma komutu tamamlandı.")

    def open_website(self, site_name: str) -> None:
        site = self.config.get("websites", {}).get(site_name)
        if not site:
            self.speak("Site kayıtlı değil.")
            return
        webbrowser.open(site.get("url"))
        self.speak(f"{site_name} açılıyor.")

    def close_browser_hint(self, site_name: str) -> None:
        self.speak(f"{site_name} sekmesini doğrudan bulup kapatmak güvenli değil. Aktif sekmeyse aktif pencereyi kapat diyebilirsin.")

    def search_web(self, query: str, provider: str = "google") -> None:
        query = query.strip()
        if not query:
            self.speak("Ne aramamı istediğini anlayamadım.")
            return
        from urllib.parse import quote_plus
        if provider == "youtube":
            url = f"https://www.youtube.com/results?search_query={quote_plus(query)}"
            webbrowser.open(url)
            self.speak(f"YouTube'da {query} aranıyor.")
        else:
            url = f"https://www.google.com/search?q={quote_plus(query)}"
            webbrowser.open(url)
            self.speak(f"Google'da {query} aranıyor.")

    # -------------------- MODLAR --------------------
    def run_scenario(self, name: str) -> None:
        scenario = self.config.get("scenarios", {}).get(name)
        if not scenario:
            self.speak("Bu mod kayıtlı değil.")
            return
        self.speak(f"{name} başlatılıyor.")
        for action in scenario.get("actions", []):
            self._run_action(action)
            time.sleep(0.25)

    # -------------------- NOT / HATIRLATICI --------------------
    def take_note(self, note: str) -> None:
        note = note.strip()
        if not note:
            self.speak("Notun içeriğini anlayamadım.")
            return
        with NOTES_PATH.open("a", encoding="utf-8") as f:
            f.write(f"[{_dt.datetime.now().strftime('%Y-%m-%d %H:%M')}] {note}\n")
        self.speak("Not aldım.")

    def open_notes(self) -> None:
        if not NOTES_PATH.exists():
            NOTES_PATH.write_text("", encoding="utf-8")
        try:
            os.startfile(str(NOTES_PATH))  # type: ignore[attr-defined]
            self.speak("Notların açılıyor.")
        except Exception:
            self.speak("Notlar dosyası açılamadı.")

    def _parse_reminder(self, text: str) -> bool:
        # Örnek: 10 dakika sonra su içmeyi hatırlat
        m = re.search(r"(\d+)\s*(dakika|dk|saat)\s*(sonra)?\s*(.*?)\s*hatirlat", text)
        if not m:
            # Örnek: hatırlat 10 dakika sonra su iç
            m = re.search(r"hatirlat\s*(\d+)\s*(dakika|dk|saat)\s*(sonra)?\s*(.*)", text)
        if not m:
            self.speak("Hatırlatıcı süresini anlayamadım. Örnek: 10 dakika sonra su içmeyi hatırlat.")
            return True
        amount = int(m.group(1))
        unit = m.group(2)
        message = (m.group(4) or "Hatırlatma zamanı geldi.").strip()
        minutes = amount * 60 if unit == "saat" else amount
        self.set_reminder(minutes, message)
        return True

    def set_reminder(self, minutes: int, message: str) -> None:
        minutes = max(1, int(minutes))
        message = message or "Hatırlatma zamanı geldi."
        def _remind():
            time.sleep(minutes * 60)
            self.notify("Jarvis Hatırlatıcı", message)
            self.speak(f"Hatırlatma: {message}")
        threading.Thread(target=_remind, daemon=True).start()
        self.speak(f"Tamam, {minutes} dakika sonra hatırlatacağım.")

    # -------------------- SİSTEM --------------------
    def take_screenshot(self) -> None:
        if pyautogui is None:
            self.speak("PyAutoGUI kurulu değil, ekran görüntüsü alamıyorum.")
            return
        try:
            file_name = f"ekran_{_dt.datetime.now().strftime('%Y%m%d_%H%M%S')}.png"
            path = SCREENSHOT_DIR / file_name
            pyautogui.screenshot(str(path))
            self.speak("Ekran görüntüsünü kaydettim.")
            self.log(f"Ekran görüntüsü: {path}")
        except Exception as exc:
            self.log(f"Ekran görüntüsü hatası: {exc}", "error")
            self.speak("Ekran görüntüsü alınamadı.")

    def report_system_status(self) -> None:
        status = get_system_status_text()
        self.speak(status)
        self.ui.update_system_text(status)

    def adjust_volume(self, action: str) -> None:
        if pyautogui is None:
            self.speak("Ses kontrolü için PyAutoGUI kurulu değil.")
            return
        try:
            if action == "up":
                pyautogui.press("volumeup", presses=5)
                self.speak("Ses artırıldı.")
            elif action == "down":
                pyautogui.press("volumedown", presses=5)
                self.speak("Ses azaltıldı.")
            else:
                pyautogui.press("volumemute")
                self.speak("Sessize alma değiştirildi.")
        except Exception:
            self.speak("Ses kontrolü başarısız oldu.")

    def open_folder(self, path: Path) -> None:
        try:
            path.mkdir(exist_ok=True) if not path.exists() and path == BASE_DIR else None
            os.startfile(str(path))  # type: ignore[attr-defined]
            self.speak("Klasör açılıyor.")
        except Exception:
            self.speak("Klasör açılamadı.")

    def close_active_window(self) -> None:
        if pyautogui is None:
            self.speak("Aktif pencereyi kapatmak için PyAutoGUI kurulu değil.")
            return
        try:
            pyautogui.hotkey("alt", "f4")
            self.speak("Aktif pencere kapatma komutu gönderildi.")
        except Exception:
            self.speak("Aktif pencere kapatılamadı.")

    def lock_pc(self) -> None:
        try:
            subprocess.Popen(["rundll32.exe", "user32.dll,LockWorkStation"])
            self.speak("Bilgisayar kilitleniyor.")
        except Exception:
            self.speak("Kilitleme komutu başarısız oldu.")

    def shutdown_pc(self) -> None:
        if self.config["settings"].get("confirm_dangerous_actions", True):
            self.speak("Bilgisayar 20 saniye içinde kapanacak. İptal etmek için kapatmayı iptal et diyebilirsin.")
        try:
            subprocess.Popen(["shutdown", "/s", "/t", "20"])
        except Exception:
            self.speak("Kapatma komutu başarısız oldu.")

    def restart_pc(self) -> None:
        self.speak("Bilgisayar 20 saniye içinde yeniden başlayacak. İptal etmek için kapatmayı iptal et diyebilirsin.")
        try:
            subprocess.Popen(["shutdown", "/r", "/t", "20"])
        except Exception:
            self.speak("Yeniden başlatma komutu başarısız oldu.")

    def cancel_shutdown(self) -> None:
        try:
            subprocess.Popen(["shutdown", "/a"])
            self.speak("Kapatma işlemi iptal edildi.")
        except Exception:
            self.speak("İptal komutu gönderilemedi.")

    def sleep_pc(self) -> None:
        self.speak("Bilgisayar uyku moduna alınıyor.")
        try:
            subprocess.Popen(["rundll32.exe", "powrprof.dll,SetSuspendState", "0,1,0"])
        except Exception:
            self.speak("Uyku modu komutu başarısız oldu.")

    def simple_calculate(self, expr: str) -> None:
        expr = expr.replace("artı", "+").replace("eksi", "-").replace("çarpı", "*").replace("carpi", "*").replace("bölü", "/").replace("bolu", "/")
        expr = re.sub(r"[^0-9\+\-\*\/\.\(\) ]", "", expr)
        if not expr.strip():
            self.speak("Hesaplamayı anlayamadım.")
            return
        try:
            value = eval(expr, {"__builtins__": {}}, {})
            self.speak(f"Sonuç {value}")
        except Exception:
            self.speak("Hesaplama yapılamadı.")

    def show_help(self) -> None:
        help_text = (
            "Örnek komutlar: Valorant aç, Roblox kapa, açtıklarımı kapat, oyun modunu aç, "
            "çalışma modunu aç, Google'da hava durumu ara, YouTube'da müzik ara, "
            "10 dakika sonra su içmeyi hatırlat, not al, sistem durumu, ekran görüntüsü al. "
            "Sohbet için nasılsın, motive et, bilgisayar yavaş veya özellik öner diyebilirsin."
        )
        self.speak(help_text)
        self.ui.show_help_dialog()


def get_system_status_text() -> str:
    if psutil is None:
        return "Sistem durumu için psutil kurulu değil."
    try:
        cpu = psutil.cpu_percent(interval=0.1)
        ram = psutil.virtual_memory()
        disk = psutil.disk_usage(str(Path.home().anchor or "C:\\"))
        battery = psutil.sensors_battery()
        battery_text = "pil bilgisi yok"
        if battery:
            battery_text = f"pil yüzde {int(battery.percent)}"
            if battery.power_plugged:
                battery_text += ", şarjda"
        return f"CPU yüzde {int(cpu)}, RAM yüzde {int(ram.percent)}, disk yüzde {int(disk.percent)}, {battery_text}."
    except Exception:
        return "Sistem durumu okunamadı."


class JarvisUI(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP_NAME)
        self.geometry("1320x820")
        self.minsize(1060, 650)
        self.config_data = load_config()
        self.theme_name = self.config_data.get("settings", {}).get("theme", "Minimal Dark")
        self.theme = THEMES.get(self.theme_name, THEMES["Minimal Dark"])
        self.engine: Optional[JarvisEngine] = None
        self.current_page = None
        self.log_text: Optional[tk.Text] = None
        self.last_heard_var = tk.StringVar(value="Henüz komut duyulmadı")
        self.status_var = tk.StringVar(value="Beklemede")
        self.status_detail_var = tk.StringVar(value="Başlatmaya hazır")
        self.system_var = tk.StringVar(value="Sistem durumu yükleniyor...")
        self._build_style()
        self._build_layout()
        self.engine = JarvisEngine(self)
        self.config_data = self.engine.config
        self.after(400, self._refresh_system_loop)
        if not self.config_data.get("first_run_done", False):
            self.after(800, self.show_setup_wizard)

    def _build_style(self) -> None:
        self.configure(bg=self.theme["bg"])
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except Exception:
            pass
        style.configure("Treeview", background=self.theme["card"], foreground=self.theme["text"], fieldbackground=self.theme["card"], bordercolor=self.theme["border"], rowheight=28)
        style.configure("Treeview.Heading", background=self.theme["panel"], foreground=self.theme["text"], relief="flat")
        style.map("Treeview", background=[("selected", self.theme["accent"])])
        style.configure("TCombobox", fieldbackground=self.theme["card"], background=self.theme["card"], foreground=self.theme["text"])

    def _build_layout(self) -> None:
        self.sidebar = tk.Frame(self, bg=self.theme["panel"], width=235)
        self.sidebar.pack(side="left", fill="y")
        self.sidebar.pack_propagate(False)

        logo = tk.Label(self.sidebar, text="JARVIS\nULTRA V6", bg=self.theme["panel"], fg=self.theme["text"], font=("Segoe UI", 22, "bold"), justify="left")
        logo.pack(anchor="w", padx=22, pady=(24, 18))
        sub = tk.Label(self.sidebar, text="Modern Voice PC Assistant", bg=self.theme["panel"], fg=self.theme["muted"], font=("Segoe UI", 9))
        sub.pack(anchor="w", padx=22, pady=(0, 20))

        self.nav_buttons: Dict[str, tk.Button] = {}
        navs = [
            ("dashboard", "Ana Panel"),
            ("apps", "Uygulamalar"),
            ("commands", "Özel Komutlar"),
            ("modes", "Modlar"),
            ("chat", "Sohbet & Ses"),
            ("settings", "Ayarlar"),
            ("logs", "Log"),
        ]
        for key, label in navs:
            btn = tk.Button(self.sidebar, text=label, command=lambda k=key: self.show_page(k), anchor="w", bd=0, padx=18, pady=12, bg=self.theme["panel"], fg=self.theme["muted"], activebackground=self.theme["card"], activeforeground=self.theme["text"], font=("Segoe UI", 11, "bold"), cursor="hand2")
            btn.pack(fill="x", padx=12, pady=3)
            self.nav_buttons[key] = btn

        self.version_label = tk.Label(self.sidebar, text="V6 Neon Voice Pro", bg=self.theme["panel"], fg=self.theme["muted"], font=("Segoe UI", 9))
        self.version_label.pack(side="bottom", pady=16)

        self.main = tk.Frame(self, bg=self.theme["bg"])
        self.main.pack(side="left", fill="both", expand=True)

        self.header = tk.Frame(self.main, bg=self.theme["bg"], height=88)
        self.header.pack(fill="x", padx=24, pady=(18, 8))
        self.header.pack_propagate(False)

        tk.Label(self.header, text="Jarvis V6 Neon Command Center", bg=self.theme["bg"], fg=self.theme["text"], font=("Segoe UI", 24, "bold")).pack(side="left", anchor="w")

        controls = tk.Frame(self.header, bg=self.theme["bg"])
        controls.pack(side="right", anchor="e")
        self.btn_stop = self._button(controls, "Durdur", lambda: self.engine.stop_listening() if self.engine else None, kind="danger")
        self.btn_stop.pack(side="right", padx=(8, 0))
        self.btn_start = self._button(controls, "Dinlemeyi Başlat", lambda: self.engine.start_listening() if self.engine else None, kind="accent")
        self.btn_start.pack(side="right", padx=(8, 0))
        self.btn_calibrate = self._button(controls, "Mikrofonu Kalibre Et", lambda: self.engine.calibrate() if self.engine else None)
        self.btn_calibrate.pack(side="right", padx=(8, 0))

        self.content = tk.Frame(self.main, bg=self.theme["bg"])
        self.content.pack(fill="both", expand=True, padx=24, pady=(0, 24))
        self.show_page("dashboard")

    def _button(self, parent, text, command, kind="normal") -> tk.Button:
        bg = self.theme["card2"]
        fg = self.theme["text"]
        if kind == "accent":
            bg = self.theme["accent"]
            fg = "#03111a"
        elif kind == "danger":
            bg = self.theme["danger"]
        elif kind == "ok":
            bg = self.theme["accent2"]
            fg = "#071421"
        return tk.Button(
            parent, text=text, command=command, bd=0, padx=18, pady=11, bg=bg, fg=fg,
            activebackground=self.theme["accent2"], activeforeground="#ffffff",
            font=("Segoe UI", 10, "bold"), cursor="hand2",
            highlightbackground=self.theme.get("accent", self.theme["border"]), highlightthickness=1
        )

    def _entry(self, parent, textvariable=None) -> tk.Entry:
        return tk.Entry(parent, textvariable=textvariable, bg=self.theme["card2"], fg=self.theme["text"], insertbackground=self.theme["text"], relief="flat", font=("Segoe UI", 10), bd=0)

    def _label(self, parent, text, size=10, bold=False, muted=False) -> tk.Label:
        return tk.Label(parent, text=text, bg=parent.cget("bg"), fg=self.theme["muted"] if muted else self.theme["text"], font=("Segoe UI", size, "bold" if bold else "normal"))

    def _card(self, parent, title: str = "") -> tk.Frame:
        # Neon hissi: keskin koyu kart + parlak ince çerçeve. Tkinter'da gerçek blur/glow yok ama bu
        # tasarım Windows'ta hafif ve stabil kalarak premium görünür.
        border = self.theme.get("accent", self.theme["border"]) if self.config_data.get("settings", {}).get("neon_effects", True) else self.theme["border"]
        card = tk.Frame(parent, bg=self.theme["card"], highlightbackground=border, highlightthickness=1)
        if title:
            header = tk.Frame(card, bg=self.theme["card"])
            header.pack(fill="x", padx=14, pady=(12, 6))
            tk.Label(header, text="◆", bg=self.theme["card"], fg=self.theme["accent"], font=("Segoe UI", 14, "bold")).pack(side="left", padx=(0, 8))
            tk.Label(header, text=title, bg=self.theme["card"], fg=self.theme["text"], font=("Segoe UI", 13, "bold")).pack(side="left")
        return card

    def clear_content(self) -> None:
        for child in self.content.winfo_children():
            child.destroy()

    def show_page(self, key: str) -> None:
        self.current_page = key
        for k, btn in self.nav_buttons.items():
            btn.configure(bg=self.theme["card"] if k == key else self.theme["panel"], fg=self.theme["text"] if k == key else self.theme["muted"])
        self.clear_content()
        if key == "dashboard":
            self.page_dashboard()
        elif key == "apps":
            self.page_apps()
        elif key == "commands":
            self.page_commands()
        elif key == "modes":
            self.page_modes()
        elif key == "chat":
            self.page_chat()
        elif key == "settings":
            self.page_settings()
        elif key == "logs":
            self.page_logs()

    # -------------------- SAYFALAR --------------------
    def page_dashboard(self) -> None:
        top = tk.Frame(self.content, bg=self.theme["bg"])
        top.pack(fill="x")
        c1 = self._card(top, "Durum")
        c1.pack(side="left", fill="both", expand=True, padx=(0, 10))
        tk.Label(c1, textvariable=self.status_var, bg=self.theme["card"], fg=self.theme["accent2"], font=("Segoe UI", 28, "bold")).pack(anchor="w", padx=16)
        tk.Label(c1, textvariable=self.status_detail_var, bg=self.theme["card"], fg=self.theme["muted"], font=("Segoe UI", 11)).pack(anchor="w", padx=16, pady=(0, 14))

        c2 = self._card(top, "Son Duyulan")
        c2.pack(side="left", fill="both", expand=True, padx=(10, 0))
        tk.Label(c2, textvariable=self.last_heard_var, wraplength=420, justify="left", bg=self.theme["card"], fg=self.theme["text"], font=("Segoe UI", 13)).pack(anchor="w", padx=16, pady=(0, 16))

        mid = tk.Frame(self.content, bg=self.theme["bg"])
        mid.pack(fill="both", expand=True, pady=18)
        system = self._card(mid, "Sistem Durumu")
        system.pack(side="left", fill="both", expand=True, padx=(0, 10))
        tk.Label(system, textvariable=self.system_var, wraplength=420, justify="left", bg=self.theme["card"], fg=self.theme["text"], font=("Segoe UI", 13)).pack(anchor="w", padx=16, pady=8)
        quick = tk.Frame(system, bg=self.theme["card"])
        quick.pack(anchor="w", padx=16, pady=(10, 16))
        self._button(quick, "Sistem durumunu söyle", lambda: self.engine.report_system_status() if self.engine else None).pack(side="left", padx=(0, 8))
        self._button(quick, "Ekran görüntüsü al", lambda: self.engine.take_screenshot() if self.engine else None).pack(side="left")

        examples = self._card(mid, "Hızlı Komutlar")
        examples.pack(side="left", fill="both", expand=True, padx=(10, 0))
        cmds = [
            "Hey Jarvis, oyun modunu aç",
            "Valorant aç / Valorant kapat",
            "Roblox kapa",
            "Açtıklarımı kapat",
            "10 dakika sonra su içmeyi hatırlat",
            "Google'da Konya hava durumu ara",
            "Ses testi / ses durumunu göster",
            "Ping testi yap / temp temizle",
            "Panoya kopyala merhaba",
        ]
        for cmd in cmds:
            tk.Label(examples, text="• " + cmd, bg=self.theme["card"], fg=self.theme["text"], font=("Segoe UI", 11), anchor="w").pack(anchor="w", padx=18, pady=3)

        bottom = self._card(self.content, "Canlı Konsol")
        bottom.pack(fill="both", expand=True)
        self.log_text = tk.Text(bottom, height=8, bg=self.theme["card"], fg=self.theme["muted"], insertbackground=self.theme["text"], relief="flat", font=("Consolas", 10), bd=0)
        self.log_text.pack(fill="both", expand=True, padx=16, pady=(0, 16))
        self.append_log("Jarvis V6 Neon Voice Pro hazır. Ses testi için: ses testi de.")

    def page_apps(self) -> None:
        card = self._card(self.content, "Uygulama ve Oyun Yönetimi")
        card.pack(fill="both", expand=True)
        top = tk.Frame(card, bg=self.theme["card"])
        top.pack(fill="x", padx=16, pady=(0, 12))
        self._button(top, "Uygulama Ekle", self.add_app_dialog, kind="accent").pack(side="left", padx=(0, 8))
        self._button(top, "Seçileni Sil", self.delete_selected_app, kind="danger").pack(side="left", padx=(0, 8))
        self._button(top, "Aç", self.open_selected_app).pack(side="left", padx=(0, 8))
        self._button(top, "Kapat", self.close_selected_app).pack(side="left")

        self.apps_tree = ttk.Treeview(card, columns=("aliases", "processes", "paths"), show="headings")
        self.apps_tree.heading("aliases", text="Uygulama")
        self.apps_tree.heading("processes", text="Process")
        self.apps_tree.heading("paths", text="Yol")
        self.apps_tree.column("aliases", width=180)
        self.apps_tree.column("processes", width=230)
        self.apps_tree.column("paths", width=520)
        self.apps_tree.pack(fill="both", expand=True, padx=16, pady=(0, 16))
        self.refresh_apps_tree()

    def page_commands(self) -> None:
        card = self._card(self.content, "Özel Komut Oluştur")
        card.pack(fill="x")
        form = tk.Frame(card, bg=self.theme["card"])
        form.pack(fill="x", padx=16, pady=(0, 16))
        tk.Label(form, text="Komut", bg=self.theme["card"], fg=self.theme["muted"]).grid(row=0, column=0, sticky="w")
        tk.Label(form, text="İşlem", bg=self.theme["card"], fg=self.theme["muted"]).grid(row=0, column=1, sticky="w", padx=(12, 0))
        tk.Label(form, text="Hedef", bg=self.theme["card"], fg=self.theme["muted"]).grid(row=0, column=2, sticky="w", padx=(12, 0))
        self.cmd_trigger_var = tk.StringVar()
        self.cmd_action_var = tk.StringVar(value="open_app")
        self.cmd_target_var = tk.StringVar()
        self._entry(form, self.cmd_trigger_var).grid(row=1, column=0, sticky="ew", ipady=9)
        combo = ttk.Combobox(form, textvariable=self.cmd_action_var, values=["open_app", "close_app", "open_url", "search_google", "screenshot", "system_status", "reminder"], state="readonly")
        combo.grid(row=1, column=1, sticky="ew", padx=(12, 0), ipady=7)
        self._entry(form, self.cmd_target_var).grid(row=1, column=2, sticky="ew", padx=(12, 0), ipady=9)
        self._button(form, "Ekle", self.add_custom_command, kind="accent").grid(row=1, column=3, padx=(12, 0))
        form.columnconfigure(0, weight=2)
        form.columnconfigure(1, weight=1)
        form.columnconfigure(2, weight=2)

        info = tk.Label(card, text="Örnek: Komut='yayın modunu aç', İşlem='open_app', Hedef='discord'. Hatırlatıcı hedefi: 10|Su iç", bg=self.theme["card"], fg=self.theme["muted"], font=("Segoe UI", 10))
        info.pack(anchor="w", padx=16, pady=(0, 12))

        list_card = self._card(self.content, "Kayıtlı Özel Komutlar")
        list_card.pack(fill="both", expand=True, pady=(16, 0))
        self.cmd_tree = ttk.Treeview(list_card, columns=("trigger", "action", "target"), show="headings")
        self.cmd_tree.heading("trigger", text="Komut")
        self.cmd_tree.heading("action", text="İşlem")
        self.cmd_tree.heading("target", text="Hedef")
        self.cmd_tree.pack(fill="both", expand=True, padx=16, pady=(0, 12))
        self._button(list_card, "Seçileni Sil", self.delete_selected_command, kind="danger").pack(anchor="w", padx=16, pady=(0, 16))
        self.refresh_commands_tree()

    def page_modes(self) -> None:
        card = self._card(self.content, "Hazır Modlar")
        card.pack(fill="x")
        row = tk.Frame(card, bg=self.theme["card"])
        row.pack(fill="x", padx=16, pady=(0, 16))
        self._button(row, "Oyun Modunu Başlat", lambda: self.engine.run_scenario("oyun modu") if self.engine else None, kind="accent").pack(side="left", padx=(0, 10))
        self._button(row, "Çalışma Modunu Başlat", lambda: self.engine.run_scenario("çalışma modu") if self.engine else None, kind="ok").pack(side="left", padx=(0, 10))
        self._button(row, "Açtıklarımı Kapat", lambda: self.engine.close_known_user_apps() if self.engine else None, kind="danger").pack(side="left")

        desc = self._card(self.content, "Mod Mantığı")
        desc.pack(fill="both", expand=True, pady=(16, 0))
        text = (
            "Oyun modu şu an Discord, Spotify ve Steam'i açar. Çalışma modu Chrome, Not Defteri ve 45 dakikalık odak hatırlatıcısı başlatır.\n\n"
            "Bunu daha da kişiselleştirmek için Özel Komutlar bölümünden kendi modunu oluşturabilirsin. Örnek: 'yayın modunu aç' komutu Discord + OBS + Twitch açabilir."
        )
        tk.Label(desc, text=text, bg=self.theme["card"], fg=self.theme["text"], wraplength=760, justify="left", font=("Segoe UI", 12)).pack(anchor="w", padx=16, pady=(0, 16))

    def page_chat(self) -> None:
        card = self._card(self.content, "Sohbet ve Ses Merkezi")
        card.pack(fill="both", expand=True)
        top = tk.Frame(card, bg=self.theme["card"])
        top.pack(fill="x", padx=16, pady=(0, 10))
        self._button(top, "Ses Testi", lambda: self.engine.speak("Ses sistemi aktif. Jarvis Ultra V6 konuşmaya hazır.") if self.engine else None, kind="accent").pack(side="left", padx=(0, 8))
        self._button(top, "Sohbet Veritabanını Aç", lambda: self.engine.open_chat_database() if self.engine else None).pack(side="left", padx=(0, 8))
        self._button(top, "Hafızayı Aç", lambda: self.engine.open_memory_file() if self.engine else None).pack(side="left")

        self.chat_text = tk.Text(card, height=18, bg=self.theme["card2"], fg=self.theme["text"], insertbackground=self.theme["text"], relief="flat", font=("Segoe UI", 11), bd=0, wrap="word")
        self.chat_text.pack(fill="both", expand=True, padx=16, pady=(0, 12))
        self.chat_text.insert("end", "Jarvis: Sohbet paneli hazır. Aşağıya yazıp Gönder diyebilirsin.\n\n")

        bottom = tk.Frame(card, bg=self.theme["card"])
        bottom.pack(fill="x", padx=16, pady=(0, 16))
        self.chat_input_var = tk.StringVar()
        ent = self._entry(bottom, self.chat_input_var)
        ent.pack(side="left", fill="x", expand=True, ipady=10)
        ent.bind("<Return>", lambda e: self.send_chat_text())
        self._button(bottom, "Gönder", self.send_chat_text, kind="accent").pack(side="left", padx=(10, 0))

        hint = "Örnek: nasılsın, beni hatırla adım Burak, hakkımda ne biliyorsun, bilgisayar yavaş, motive et, özellik öner."
        tk.Label(card, text=hint, bg=self.theme["card"], fg=self.theme["muted"], font=("Segoe UI", 10), wraplength=860, justify="left").pack(anchor="w", padx=16, pady=(0, 14))

    def page_settings(self) -> None:
        card = self._card(self.content, "Dinleme ve Arayüz Ayarları")
        card.pack(fill="both", expand=True)
        s = self.config_data.get("settings", {})
        form = tk.Frame(card, bg=self.theme["card"])
        form.pack(anchor="nw", padx=18, pady=(0, 18), fill="x")

        self.set_wake_var = tk.BooleanVar(value=bool(s.get("wake_enabled", False)))
        self.set_voice_var = tk.BooleanVar(value=bool(s.get("voice_enabled", True)))
        self.set_theme_var = tk.StringVar(value=s.get("theme", "Neon Cyber"))
        self.set_chime_var = tk.BooleanVar(value=bool(s.get("speak_chime_enabled", True)))
        self.set_chat_var = tk.BooleanVar(value=bool(s.get("chat_enabled", True)))
        self.set_voice_rate_var = tk.StringVar(value=str(s.get("voice_rate", 174)))
        self.set_wake_words_var = tk.StringVar(value=", ".join(s.get("wake_words", [])))
        self.set_phrase_var = tk.StringVar(value=str(s.get("phrase_time_limit", 20)))
        self.set_pause_var = tk.StringVar(value=str(s.get("pause_threshold", 1.85)))
        self.set_timeout_var = tk.StringVar(value=str(s.get("listen_timeout", 8)))

        chk1 = tk.Checkbutton(form, text="Hey Jarvis uyandırma kelimesi aktif", variable=self.set_wake_var, bg=self.theme["card"], fg=self.theme["text"], selectcolor=self.theme["panel"], activebackground=self.theme["card"], activeforeground=self.theme["text"], font=("Segoe UI", 11))
        chk1.grid(row=0, column=0, columnspan=2, sticky="w", pady=6)
        chk2 = tk.Checkbutton(form, text="Sesli cevap aktif", variable=self.set_voice_var, bg=self.theme["card"], fg=self.theme["text"], selectcolor=self.theme["panel"], activebackground=self.theme["card"], activeforeground=self.theme["text"], font=("Segoe UI", 11))
        chk2.grid(row=1, column=0, columnspan=2, sticky="w", pady=6)
        chk3 = tk.Checkbutton(form, text="Konuşmadan önce özel ses efekti çal", variable=self.set_chime_var, bg=self.theme["card"], fg=self.theme["text"], selectcolor=self.theme["panel"], activebackground=self.theme["card"], activeforeground=self.theme["text"], font=("Segoe UI", 11))
        chk3.grid(row=2, column=0, columnspan=2, sticky="w", pady=6)
        chk4 = tk.Checkbutton(form, text="Gelişmiş sohbet modu aktif", variable=self.set_chat_var, bg=self.theme["card"], fg=self.theme["text"], selectcolor=self.theme["panel"], activebackground=self.theme["card"], activeforeground=self.theme["text"], font=("Segoe UI", 11))
        chk4.grid(row=3, column=0, columnspan=2, sticky="w", pady=6)

        labels = [
            ("Tema", self.set_theme_var, "combo"),
            ("Konuşma hızı", self.set_voice_rate_var, "entry"),
            ("Uyandırma kelimeleri", self.set_wake_words_var, "entry"),
            ("Tek cümle maksimum süresi", self.set_phrase_var, "entry"),
            ("Cümle bitti sayılacak sessizlik", self.set_pause_var, "entry"),
            ("Dinleme timeout", self.set_timeout_var, "entry"),
        ]
        for i, (label, var, typ) in enumerate(labels, start=4):
            tk.Label(form, text=label, bg=self.theme["card"], fg=self.theme["muted"], font=("Segoe UI", 10)).grid(row=i, column=0, sticky="w", pady=(10, 2))
            if typ == "combo":
                w = ttk.Combobox(form, textvariable=var, values=list(THEMES.keys()), state="readonly")
                w.grid(row=i, column=1, sticky="ew", padx=(16, 0), pady=(10, 2), ipady=5)
            else:
                self._entry(form, var).grid(row=i, column=1, sticky="ew", padx=(16, 0), pady=(10, 2), ipady=8)
        form.columnconfigure(1, weight=1)
        self._button(form, "Ayarları Kaydet", self.save_settings, kind="accent").grid(row=11, column=1, sticky="e", pady=18)
        self._button(form, "Ses Testi", lambda: self.engine.speak("Jarvis Ultra V6 ses testi. Şu an konuşuyorum.") if self.engine else None, kind="ok").grid(row=11, column=0, sticky="w", pady=18)

        hint = (
            "Cümleyi yarıda keserse: 'Tek cümle maksimum süresi' değerini 25-30 yap, "
            "'Cümle bitti sayılacak sessizlik' değerini 1.60-2.00 arası dene."
        )
        tk.Label(card, text=hint, bg=self.theme["card"], fg=self.theme["muted"], wraplength=780, justify="left", font=("Segoe UI", 11)).pack(anchor="w", padx=18, pady=(0, 18))

    def page_logs(self) -> None:
        card = self._card(self.content, "Log ve Hata Kaydı")
        card.pack(fill="both", expand=True)
        self.log_text = tk.Text(card, bg=self.theme["card"], fg=self.theme["muted"], insertbackground=self.theme["text"], relief="flat", font=("Consolas", 10), bd=0)
        self.log_text.pack(fill="both", expand=True, padx=16, pady=(0, 16))
        if LOG_PATH.exists():
            try:
                data = LOG_PATH.read_text(encoding="utf-8")[-12000:]
                self.log_text.insert("end", data)
            except Exception:
                pass

    # -------------------- UI AKSİYONLAR --------------------
    def send_chat_text(self) -> None:
        text = getattr(self, "chat_input_var", tk.StringVar()).get().strip()
        if not text:
            return
        if hasattr(self, "chat_input_var"):
            self.chat_input_var.set("")
        self.add_chat_message("Sen", text)
        if self.engine:
            self.engine.execute_command(text, original=text)

    def add_chat_message(self, who: str, text: str) -> None:
        def _add():
            if hasattr(self, "chat_text") and self.chat_text and self.chat_text.winfo_exists():
                self.chat_text.insert("end", f"{who}: {text}\n\n")
                self.chat_text.see("end")
        self.after(0, _add)

    def append_log(self, message: str) -> None:
        def _append():
            if self.log_text and self.log_text.winfo_exists():
                ts = _dt.datetime.now().strftime("%H:%M:%S")
                self.log_text.insert("end", f"[{ts}] {message}\n")
                self.log_text.see("end")
        self.after(0, _append)

    def set_status(self, status: str, detail: str = "") -> None:
        self.after(0, lambda: (self.status_var.set(status), self.status_detail_var.set(detail)))

    def set_last_heard(self, text: str) -> None:
        self.after(0, lambda: self.last_heard_var.set(text))

    def update_system_text(self, text: str) -> None:
        self.after(0, lambda: self.system_var.set(text))

    def _refresh_system_loop(self) -> None:
        self.system_var.set(get_system_status_text())
        self.after(3000, self._refresh_system_loop)

    def refresh_apps_tree(self) -> None:
        if not hasattr(self, "apps_tree"):
            return
        for i in self.apps_tree.get_children():
            self.apps_tree.delete(i)
        for name, data in self.config_data.get("apps", {}).items():
            self.apps_tree.insert("", "end", iid=name, values=(name + " | " + ", ".join(data.get("aliases", [])[:3]), ", ".join(data.get("processes", [])[:3]), "; ".join(data.get("paths", [])[:2])))

    def add_app_dialog(self) -> None:
        win = tk.Toplevel(self)
        win.title("Uygulama Ekle")
        win.geometry("610x360")
        win.configure(bg=self.theme["bg"])
        name_var = tk.StringVar()
        aliases_var = tk.StringVar()
        path_var = tk.StringVar()
        proc_var = tk.StringVar()

        def browse():
            p = filedialog.askopenfilename(title="EXE veya kısayol seç", filetypes=[("Uygulama/Kısayol", "*.exe *.lnk"), ("Tüm dosyalar", "*.*")])
            if p:
                path_var.set(p)
                if not name_var.get():
                    name_var.set(Path(p).stem.lower())
                if p.lower().endswith(".exe") and not proc_var.get():
                    proc_var.set(Path(p).name)

        def save():
            name = normalize(name_var.get())
            if not name or not path_var.get():
                messagebox.showwarning("Eksik", "Uygulama adı ve yol gerekli.")
                return
            self.config_data.setdefault("apps", {})[name] = {
                "aliases": [a.strip() for a in aliases_var.get().split(",") if a.strip()] or [name],
                "paths": [path_var.get()],
                "processes": [p.strip() for p in proc_var.get().split(",") if p.strip()],
                "arguments": [],
            }
            save_config(self.config_data)
            if self.engine:
                self.engine.config = self.config_data
            self.refresh_apps_tree()
            win.destroy()

        rows = [("Ad", name_var), ("Takma adlar, virgülle", aliases_var), ("Yol", path_var), ("Process adları, virgülle", proc_var)]
        for i, (label, var) in enumerate(rows):
            tk.Label(win, text=label, bg=self.theme["bg"], fg=self.theme["muted"]).grid(row=i, column=0, sticky="w", padx=20, pady=(18 if i == 0 else 10, 4))
            self._entry(win, var).grid(row=i, column=1, sticky="ew", padx=20, pady=(18 if i == 0 else 10, 4), ipady=8)
        self._button(win, "Dosya Seç", browse).grid(row=2, column=2, padx=(0, 20), pady=10)
        self._button(win, "Kaydet", save, kind="accent").grid(row=4, column=1, sticky="e", padx=20, pady=24)
        win.columnconfigure(1, weight=1)

    def selected_app_name(self) -> Optional[str]:
        sel = getattr(self, "apps_tree", None).selection() if hasattr(self, "apps_tree") else []
        return sel[0] if sel else None

    def delete_selected_app(self) -> None:
        name = self.selected_app_name()
        if not name:
            return
        if messagebox.askyesno("Sil", f"{name} silinsin mi?"):
            self.config_data.get("apps", {}).pop(name, None)
            save_config(self.config_data)
            if self.engine:
                self.engine.config = self.config_data
            self.refresh_apps_tree()

    def open_selected_app(self) -> None:
        name = self.selected_app_name()
        if name and self.engine:
            self.engine.open_app(name)

    def close_selected_app(self) -> None:
        name = self.selected_app_name()
        if name and self.engine:
            self.engine.close_app(name)

    def add_custom_command(self) -> None:
        trigger = self.cmd_trigger_var.get().strip()
        action = self.cmd_action_var.get().strip()
        target = self.cmd_target_var.get().strip()
        if not trigger:
            messagebox.showwarning("Eksik", "Komut adı gerekli.")
            return
        self.config_data.setdefault("custom_commands", []).append({
            "trigger": trigger,
            "actions": [{"type": action, "target": target}],
        })
        save_config(self.config_data)
        if self.engine:
            self.engine.config = self.config_data
        self.cmd_trigger_var.set("")
        self.cmd_target_var.set("")
        self.refresh_commands_tree()

    def refresh_commands_tree(self) -> None:
        if not hasattr(self, "cmd_tree"):
            return
        for i in self.cmd_tree.get_children():
            self.cmd_tree.delete(i)
        for idx, item in enumerate(self.config_data.get("custom_commands", [])):
            action = item.get("actions", [{}])[0]
            self.cmd_tree.insert("", "end", iid=str(idx), values=(item.get("trigger"), action.get("type"), action.get("target")))

    def delete_selected_command(self) -> None:
        sel = self.cmd_tree.selection() if hasattr(self, "cmd_tree") else []
        if not sel:
            return
        idx = int(sel[0])
        cmds = self.config_data.get("custom_commands", [])
        if 0 <= idx < len(cmds):
            cmds.pop(idx)
            save_config(self.config_data)
            if self.engine:
                self.engine.config = self.config_data
            self.refresh_commands_tree()

    def save_settings(self) -> None:
        try:
            s = self.config_data.setdefault("settings", {})
            s["wake_enabled"] = bool(self.set_wake_var.get())
            s["voice_enabled"] = bool(self.set_voice_var.get())
            s["speak_chime_enabled"] = bool(self.set_chime_var.get())
            s["chat_enabled"] = bool(self.set_chat_var.get())
            s["voice_rate"] = int(float(self.set_voice_rate_var.get()))
            s["theme"] = self.set_theme_var.get()
            s["wake_words"] = [w.strip() for w in self.set_wake_words_var.get().split(",") if w.strip()]
            s["phrase_time_limit"] = float(self.set_phrase_var.get())
            s["pause_threshold"] = float(self.set_pause_var.get())
            s["listen_timeout"] = float(self.set_timeout_var.get())
            save_config(self.config_data)
            if self.engine:
                self.engine.config = self.config_data
                self.engine._init_tts()
            messagebox.showinfo("Kaydedildi", "Ayarlar kaydedildi. Tema değiştiyse programı kapatıp aç.")
        except Exception as exc:
            messagebox.showerror("Hata", f"Ayar kaydedilemedi: {exc}")

    def show_setup_wizard(self) -> None:
        win = tk.Toplevel(self)
        win.title("İlk Kurulum")
        win.geometry("620x430")
        win.configure(bg=self.theme["bg"])
        win.transient(self)
        tk.Label(win, text="Jarvis Ultra V6'e hoş geldin", bg=self.theme["bg"], fg=self.theme["text"], font=("Segoe UI", 22, "bold")).pack(anchor="w", padx=26, pady=(24, 8))
        msg = (
            "Bu sihirbaz sadece ilk açılışta çıkar.\n\n"
            "1) Uygulamalar bölümünden oyunlarını ekleyebilirsin.\n"
            "2) Ayarlar bölümünden Hey Jarvis uyandırma kelimesini açabilirsin.\n"
            "3) Özel Komutlar ile kendi senaryonu oluşturabilirsin.\n\n"
            "Cümleyi yarıda keserse Ayarlar > Tek cümle maksimum süresi değerini yükselt."
        )
        tk.Label(win, text=msg, bg=self.theme["bg"], fg=self.theme["muted"], justify="left", wraplength=560, font=("Segoe UI", 12)).pack(anchor="w", padx=26, pady=10)
        wake_var = tk.BooleanVar(value=False)
        tk.Checkbutton(win, text="Hey Jarvis uyandırma kelimesini hemen aktif et", variable=wake_var, bg=self.theme["bg"], fg=self.theme["text"], selectcolor=self.theme["panel"], activebackground=self.theme["bg"], activeforeground=self.theme["text"], font=("Segoe UI", 11)).pack(anchor="w", padx=26, pady=12)

        def finish():
            self.config_data["first_run_done"] = True
            self.config_data.setdefault("settings", {})["wake_enabled"] = bool(wake_var.get())
            save_config(self.config_data)
            if self.engine:
                self.engine.config = self.config_data
            win.destroy()
        self._button(win, "Başla", finish, kind="accent").pack(anchor="e", padx=26, pady=22)

    def show_help_dialog(self) -> None:
        text = (
            "KOMUT ÖRNEKLERİ\n\n"
            "• Valorant aç / Valorant kapat\n"
            "• Roblox kapa\n"
            "• Açtıklarımı kapat\n"
            "• Oyun modunu aç\n"
            "• Çalışma modunu aç\n"
            "• Google'da Konya hava durumu ara\n"
            "• YouTube'da klasik müzik ara\n"
            "• 10 dakika sonra su içmeyi hatırlat\n"
            "• Not al bugün dosyaları düzenle\n"
            "• Sistem durumu nedir\n"
            "• Ekran görüntüsü al\n"
            "• Bilgisayarı kilitle\n"
            "• Ses testi / Sohbet modu aç\n"
            "• Beni hatırla adım Burak\n"
            "• Hakkımda ne biliyorsun\n"
            "• Bilgisayar yavaş / motive et / özellik öner\n"
            "• Kapatmayı iptal et\n\n"
            "Hey Jarvis aktifse önce 'Hey Jarvis' demen gerekir."
        )
        messagebox.showinfo("Komut Listesi", text)


def main() -> None:
    try:
        app = JarvisUI()
        app.mainloop()
    except Exception:
        logging.error(traceback.format_exc())
        raise


if __name__ == "__main__":
    main()
